export const wallColor = 'gray';
export const passColor = 'white';
export const startColor = 'yellow';
export const finishColor = 'red';
export const pathColor = 'violet';
export const bypassableColor = 'orange';
export const currentColor = 'blue'
